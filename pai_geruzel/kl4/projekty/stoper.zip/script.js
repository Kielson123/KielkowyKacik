let czas = document.getElementById('czas')
let start_btn = document.getElementById('start')
let stop_btn = document.getElementById('stop')
let reset_btn = document.getElementById('reset')

let interval

function start(){
    interval = setInterval(() => {
        let stoper = parseFloat(czas.innerText)
        let time = parseFloat(stoper + 0.01).toFixed(2)
        czas.innerText = time.length > 4 ? time : '0' + time
    }, 10)
    start_btn.setAttribute('hidden', true)
    stop_btn.removeAttribute('hidden')
}

function stop(){
    clearInterval(interval)
    stop_btn.setAttribute('hidden', true)
    start_btn.removeAttribute('hidden')
}

function reset(){
    clearInterval(interval)
    stop_btn.setAttribute('hidden', true)
    start_btn.removeAttribute('hidden')
    czas.innerText = '00.00'
}