function kolor(){
    let suwak1 = document.getElementById('suwak1').value
    let suwak2 = document.getElementById('suwak2').value
    let suwak3 = document.getElementById('suwak3').value
    let box = document.getElementById('box')

    box.style.backgroundColor = `rgb(${suwak1}, ${suwak2}, ${suwak3})`
}

kolor()
rozmiar()

function rozmiar(){
    let suwak4 = document.getElementById('suwak4').value
    let box = document.getElementById('box')

    box.style.width = `${suwak4}px`
    box.style.height = `${suwak4}px`
}