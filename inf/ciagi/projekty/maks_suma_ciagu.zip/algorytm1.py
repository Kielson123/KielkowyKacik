A = [23, -49, 6, 23, 24, -42, 40, 4, -48, 39]
n = len(A)

maks_suma = 0
for i in range(0, n):
    for j in range(i, n):
        akt_suma = 0
        for k in range(i, j):
            akt_suma += A[k]
        if akt_suma > maks_suma:
            maks_suma = akt_suma

print(maks_suma)