A = [-26, 11, -45, 40, -49, 36, 16, 18, 42, -10]
n = len(A)

maks_suma = 0
akt_suma = 0
for i in range(0, n):
    if akt_suma + A[i] > 0:
        akt_suma += A[i]
        if maks_suma < akt_suma:
            maks_suma = akt_suma
    else:
        akt_suma = 0

print(maks_suma)