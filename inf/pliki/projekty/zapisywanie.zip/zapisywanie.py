with open('zad2.txt', 'r') as plik:
    dane = plik.read()
print(dane, '\n')

with open('zad2.txt', 'r') as plik:
    dane_lista = plik.readlines()
    for i in range(len(dane_lista)):
        dane_lista[i] = dane_lista[i].strip()
        dane_lista[i] = dane_lista[i].split()
print(dane_lista, '\n')

for x in dane_lista:
    print(x)

ile = 0
for i in dane_lista:
    if len(i) > 1:
        if len(i[0]) == int(i[1]):
            ile += 1

wynik = f"\nWynik: {ile}"
print(wynik)

with open('zad2.txt', 'a') as plik:
    plik.writelines(wynik)