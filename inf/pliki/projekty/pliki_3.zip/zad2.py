n = int(input("Podaj ilość studentów: "))

with open('zad2.txt', 'w') as plik:
    for i in range(n):
        nazwisko = input("Nazwisko: ")
        imie = input("Imie: ")
        wiek = input("Wiek: ")
        while not wiek.isdigit():
            wiek = input("Wiek musi być liczbą! Wiek: ")
        miejsce = input("Miejsce urodzenia: ")
        telefon = input("Telefon: ")
        plik.writelines(nazwisko + '$' + imie + '$' + wiek + '$' + miejsce + '$' + telefon)
        plik.writelines('\n')

osoby = []

with open('zad2.txt', 'r') as plik:
    dane = plik.readlines()
    for linia in dane:
        linia = linia.strip().split('$')
        osoby.append({
            "nazwisko": linia[0],
            "imie": linia[1],
            "wiek": int(linia[2]),
            "miejsce": linia[3],
            "telefon": linia[4]
        })

for osoba in osoby:
    print(osoba["nazwisko"] + ": " + osoba["telefon"])

avg = 0
for osoba in osoby:
    avg += osoba["wiek"]
avg /= len(osoby)
print("\nŚredni wiek studentów:", avg)

print("\n---Studenci na 'A'---")
for osoba in osoby:
    if osoba["nazwisko"][0] == "A":
        print(osoba["nazwisko"], osoba["imie"])