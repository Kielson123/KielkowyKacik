import random

with open('zad1.txt', 'w') as plik:
    for i in range(10):
        plik.write(str(random.randint(1, 16)))
        plik.writelines('\n')

liczby = []
with open('zad1.txt', 'r') as plik:
    dane = plik.readlines()
    for linia in dane:
        linia = linia.strip()
        if linia != '':
            liczby.append(int(linia))


print("---Liczby mniejsze od 15---")
for liczba in liczby:
    if liczba < 15:
        print(liczba)

print("\n---Średnia---")
avg = 0
ilosc = 0
for liczba in liczby:
    if liczba < 11:
        ilosc += 1
        avg += liczba
avg /= ilosc
print(round(avg, 2))


with open('zad1-1.txt', 'w') as plik:
    for liczba in liczby:
        if liczba % 3 != 0:
            plik.writelines(str(liczba))
            plik.writelines('\n')

print("\n---Niepodzielne przez 3---")
with open('zad1-1.txt', 'r') as plik:
    dane = plik.readlines()
    for linia in dane:
        linia = linia.strip()
        if linia != '':
            print(linia)