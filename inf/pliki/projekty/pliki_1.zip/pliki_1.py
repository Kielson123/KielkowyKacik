import math

def czy_pierwsza(liczba):
    if liczba == 0 or liczba == 1:
        return False
    for i in range(2, int(math.sqrt(liczba) + 1)):
        if liczba % i == 0:
            return False
    return True

plik = open('liczby.txt', 'r')

ilosc = 0
l_pierwsze = []
for linia in plik:
    linia = int(linia.strip())

    if czy_pierwsza(linia):
        print(linia, ' liczba pierwsza')
        l_pierwsze.append(linia)
        ilosc += 1
    else:
        print(linia)
            
print(f"\n\nIlosć liczb pierwszych: {ilosc}")
print(l_pierwsze)

plik.close()