import math

def czy_pierwsza(liczba):
    if liczba == 0 or liczba == 1:
        return False
    for i in range(2, int(math.sqrt(liczba) + 1)):
        if liczba % i == 0:
            return False
    return True

plik = open('liczby.txt', 'r')

ilosc = 0

for linia in plik:
    linia = linia.strip().split()

    for liczba in linia:
        liczba = int(liczba)
        print(liczba)
        if czy_pierwsza(liczba):
            ilosc += 1

print(f"\n\nIlosć liczb pierwszych: {ilosc}")

plik.close()