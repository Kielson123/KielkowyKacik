def dec(podstawa, liczba):
    podstawa = int(podstawa)
    liczba = str(liczba)
    wartosc = 0
    for i in range(len(liczba)):
        wartosc = (wartosc * podstawa) + ord(liczba[i]) - 48
    return wartosc


plik = open('zad_lider.txt', 'r')
suma = 0
for linia in plik:
    linia = linia.strip().split(' ')
    podstawa = linia[0]
    liczba = linia[1]
    suma += dec(podstawa, liczba)
print(suma)