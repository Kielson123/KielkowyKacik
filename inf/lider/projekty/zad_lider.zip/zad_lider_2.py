def dec(podstawa, liczba):
    podstawa = int(podstawa)
    liczba = str(liczba)
    wartosc  = 0
    for i in range(len(liczba)):
        wartosc  = (wartosc * podstawa) + ord(liczba[i]) - 48
    return wartosc


min_wartosc, min_liczba, min_podstawa = 2**128, 2**128, 2**128
max_wartosc, max_liczba, max_podstawa = -(2**128), -(2**128), -(2**128)

plik = open('zad_lider.txt', 'r')
for linia in plik:
    linia = linia.strip().split(' ')

    podstawa = linia[0]
    liczba = linia[1]
    wartosc = dec(podstawa, liczba)


    if wartosc > max_wartosc:
        max_wartosc = wartosc
        max_podstawa = podstawa
        max_liczba = liczba
        print(linia)

    if wartosc < min_wartosc:
        min_wartosc = wartosc
        min_podstawa = podstawa
        min_liczba = liczba
        print(linia)


print(f"Minimum:  podstawa = {min_podstawa}, liczba = '{min_liczba}'")
print(f"Maksimum: podstawa = {max_podstawa}, liczba = '{max_liczba}'")